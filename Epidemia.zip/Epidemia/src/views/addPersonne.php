<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset=https://github.com/twbs/bootstrap/blob/master/LICENSE>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulaire d'ajout de Personne</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>
<body>
    <div class="container mt-5">
        <h1 class="mb-4">Formulaire d'ajout de Personne</h1>
        <form action="http://localhost/Epidemia/src/controller/PersonneController.php" method="post" class="border p-4">
            <div class="form-group">
                <label for="nomP">Nom :</label>
                <input type="text" name="nomP" id="nomP" class="form-control" required/>
            </div>
            <div class="form-group">
                <label for="prenomP">Prenom :</label>
                <input type="text" name="prenomP" id="prenomP" class="form-control" required/>
            </div>
            <div class="form-group">
                <label for="numTel">Numero de téléphone :</label>
                <input type="number" name="numTel" id="numTel" class="form-control" required/>
            </div>
            <div class="form-group">
                <label for="adresse">Adresse :</label>
                <input type="text" name="adresse" id="adresse" class="form-control" required/>
            </div>
            <div class="form-group">
                <label for="sexe">Sexe :</label>
                <input type="text" name="sexe" id="sexe" class="form-control" required/>
            </div>
            <div class="form-group">
                <label for="résultat">Résultat :</label>
                <select name="résultat" id="résultat" class="form-control" required>
                    <option value="" disabled selected>Choisir une option</option>
                    <option value="positive">Positive</option>
                    <option value="négative">Négative</option>
                    <option value="symptômatique">Symptômatique</option>
                </select>
            </div>
            <div class="form-group">
                <button type="submit" name="submit" class="btn btn-primary mr-2">Enregistrer</button>
                <button type="reset" name="reset" class="btn btn-secondary">Annuler</button>
            </div>
        </form>
    </div>
</body>
</html>
